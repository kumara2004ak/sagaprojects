<template>
  <div class="min-h-screen bg-gray-50">
    <Header @toggle-sidebar="toggleSidebar" />

    <div class="flex">
      <Sidebar
        :currentRoute="$route.name"
        :class="{ 'hidden md:block': !sidebarOpen, 'block': sidebarOpen }"
        @navigate="handleNavigation"
      />

      <main class="flex-1 min-h-screen bg-neutral-50 transition-all duration-300">
        <div class="p-2 md:p-2 lg:p-4">
          <transition name="fade" mode="out-in">
            <router-view />
          </transition>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";

const sidebarOpen = ref(false);
const toggleSidebar = () => {
  sidebarOpen.value = !sidebarOpen.value;
};
const handleNavigation = (route) => {
  console.log("Navigating to:", route);
};
</script>
