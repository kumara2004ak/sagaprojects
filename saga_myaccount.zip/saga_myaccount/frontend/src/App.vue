<template>
  <div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <Header @toggle-sidebar="toggleSidebar" />

    <div class="flex ">
      <!-- Sidebar -->
      <Sidebar
        :currentRoute="$route.name"
        :class="{ 'hidden md:block': !sidebarOpen, 'block': sidebarOpen }"
        @navigate="handleNavigation"
      />

      <!-- Main Content -->
      <main class="flex-1 min-h-screen bg-neutral-50 transition-all duration-300 ease-in-out">
        <div class="p-2 md:p-2 lg:p-4">
          <transition name="fade" mode="out-in">
            <router-view />
          </transition>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue"
import { useRouter } from "vue-router"
import Header from "./components/Header.vue"
import Sidebar from "./components/Sidebar.vue"

const sidebarOpen = ref(false)
const router = useRouter()

const toggleSidebar = () => {
  sidebarOpen.value = !sidebarOpen.value
}

const handleNavigation = (route) => {
  router.push(route)
}
</script>

<style scoped>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
