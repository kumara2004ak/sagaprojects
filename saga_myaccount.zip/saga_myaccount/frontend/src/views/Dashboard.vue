<template>
  <div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <header class="bg-white border-b border-gray-200 px-6 py-3">
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-4">
          <h1 class="text-xl font-semibold text-gray-900">Dashboard</h1>
        </div>
        <div class="flex items-center space-x-4">
          <div class="relative">
            <button class="p-2 text-gray-400 hover:text-gray-600 relative">
              <Bell class="h-5 w-5" />
              <span class="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full"></span>
            </button>
          </div>
          <div class="h-8 w-8 rounded-full bg-gray-800 flex items-center justify-center">
            <User class="h-4 w-4 text-white" />
          </div>
        </div>
      </div>
    </header>

    <div class="flex">
      <!-- Sidebar -->
      <aside class="w-64 bg-white border-r border-gray-200 min-h-screen">
        <div class="p-4">
          <div class="flex items-center space-x-3 mb-6">
            <div class="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span class="text-white font-semibold text-sm">S</span>
            </div>
            <span class="font-semibold text-gray-900">SagalD</span>
          </div>
          
          <nav class="space-y-2">
            <div v-for="item in sidebarItems" :key="item.name" class="space-y-1">
              <button 
                @click="item.expanded = !item.expanded"
                class="w-full flex items-center justify-between px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-md"
              >
                <div class="flex items-center space-x-3">
                  <component :is="item.icon" class="h-4 w-4" />
                  <span>{{ item.name }}</span>
                </div>
                <ChevronDown 
                  v-if="item.hasChildren" 
                  :class="['h-4 w-4 transition-transform', item.expanded ? 'rotate-180' : '']" 
                />
              </button>
            </div>
          </nav>
        </div>
      </aside>

      <!-- Main Content -->
      <main class="flex-1 p-6">
        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        
          <div class="bg-white rounded-lg border border-gray-200 p-6">
            <div class="flex items-center space-x-4">
              <div class="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Globe class="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p class="text-sm text-gray-600">Total Domains</p>
                <p class="text-2xl font-bold text-gray-900">3</p>
              </div>
            </div>
          </div>

          <!-- HRMatrix Card -->
          <div class="bg-white rounded-lg border border-gray-200 p-6">
            <div class="flex items-center justify-between">
              <div class="flex items-center space-x-4">
                <div class="h-10 w-10 bg-orange-100 rounded-lg flex items-center justify-center">
                  <FileText class="h-5 w-5 text-orange-600" />
                </div>
                <div>
                  <h3 class="font-semibold text-gray-900">HRMatrix</h3>
                  <p class="text-sm text-gray-600">hr</p>
                  <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 mt-1">
                    active
                  </span>
                </div>
              </div>
              <button class="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700">
                Launch
              </button>
            </div>
          </div>
        </div>

        <!-- Tabs -->
        <div class="mb-6">
          <div class="border-b border-gray-200">
            <nav class="-mb-px flex space-x-8">
              <button 
                v-for="tab in tabs" 
                :key="tab.name"
                @click="activeTab = tab.name"
                :class="[
                  'py-2 px-1 border-b-2 font-medium text-sm',
                  activeTab === tab.name 
                    ? 'border-blue-500 text-blue-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                ]"
              >
                {{ tab.name }}
              </button>
            </nav>
          </div>
        </div>

        <!-- Groups Table -->
        <div class="bg-white rounded-lg border border-gray-200">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex items-center justify-between">
              <h2 class="text-lg font-semibold text-gray-900">All Groups</h2>
              <div class="relative">
                <Search class="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  v-model="searchQuery"
                  type="text"
                  placeholder="Search groups"
                  class="pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>
          
          <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
              <thead class="bg-gray-50">
                <tr>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Group Name
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Purpose
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Owner
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Members
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody class="bg-white divide-y divide-gray-200">
                <tr v-for="group in filteredGroups" :key="group.id" class="hover:bg-gray-50">
                  <td class="px-6 py-4 whitespace-nowrap">
                    <div class="flex items-center">
                      <div :class="['h-8 w-8 rounded-md flex items-center justify-center mr-3', group.iconBg]">
                        <component :is="group.icon" :class="['h-4 w-4', group.iconColor]" />
                      </div>
                      <div>
                        <div class="text-sm font-medium text-gray-900">{{ group.name }}</div>
                        <div class="text-sm text-gray-500">{{ group.joined }}</div>
                      </div>
                    </div>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {{ group.purpose }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-blue-600">
                    {{ group.owner }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {{ group.members }}
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap">
                    <span :class="[
                      'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
                      group.status === 'owner' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
                    ]">
                      {{ group.status }}
                    </span>
                  </td>
                  <td class="px-6 py-4 whitespace-nowrap text-sm">
                    <button class="text-blue-600 hover:text-blue-900 font-medium">
                      View Details
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { 
  Bell, 
  User, 
  Globe, 
  FileText, 
  Search, 
  ChevronDown,
  Code,
  Palette,
  Headphones,
  Link,
  Users,
  Home,
  Briefcase,
  Shield,
  BarChart,
  Settings
} from 'lucide-vue-next'

const activeTab = ref('Organization Info')
const searchQuery = ref('')

const tabs = [
  { name: 'Organization Info' },
  { name: 'Office Locations' },
  { name: 'Designations' }
]

const sidebarItems = ref([
  { name: 'Msp Org', icon: Link, hasChildren: true, expanded: false },
  { name: 'Directory', icon: Users, hasChildren: true, expanded: false },
  { name: 'My Accont', icon: Home, hasChildren: true, expanded: false },
  { name: 'WorkSpace', icon: Briefcase, hasChildren: true, expanded: false },
  { name: 'Security', icon: Shield, hasChildren: true, expanded: false },
  { name: 'Report', icon: BarChart, hasChildren: false, expanded: false },
  { name: 'Settings', icon: Settings, hasChildren: false, expanded: false }
])

const groups = ref([
  {
    id: 1,
    name: 'Development Team',
    joined: 'Joined: Jan 15, 2025',
    purpose: 'Software Development',
    owner: 'Sarah Johnson',
    members: '12 members',
    status: 'member',
    icon: Code,
    iconBg: 'bg-blue-100',
    iconColor: 'text-blue-600'
  },
  {
    id: 2,
    name: 'Design Guild',
    joined: 'Joined: Mar 3, 2025',
    purpose: 'UX/UI Design',
    owner: 'Michael Chen',
    members: '8 members',
    status: 'member',
    icon: Palette,
    iconBg: 'bg-green-100',
    iconColor: 'text-green-600'
  },
  {
    id: 3,
    name: 'Customer Success',
    joined: 'Owner',
    purpose: 'Customer Support',
    owner: 'You',
    members: '7 members',
    status: 'owner',
    icon: Headphones,
    iconBg: 'bg-gray-100',
    iconColor: 'text-gray-600'
  }
])

const filteredGroups = computed(() => {
  if (!searchQuery.value) return groups.value
  return groups.value.filter(group => 
    group.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
    group.purpose.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})
</script>

<style scoped>
/* Additional custom styles if needed */
</style>
