import { createRouter, createWebHistory } from "vue-router"
import DefaultLayout from "@/layouts/DefaultLayout.vue"

const routes = [
  {
    path: "/",
    component: DefaultLayout,
    children: [
      {
        path: "",
        name: "Dashboard",
        component: () => import("@/views/Dashboard.vue"),
      },
      {
        path: "my-profile",
        name: "My Profile",
        component: () => import("@/views/Profile.vue"),
        meta: { title: "My Account" },
      },
      {
        path: "my-groups",
        name: "My Groups",
        component: () => import("@/views/group.vue"),
        meta: { title: "My Groups" },
      },
      // {
      //   path: "my-apps",
      //   name: "My Apps",
      //   component: () => import("@/views/Apps.vue"),
      //   meta: { title: "My Apps" },
      // },
      // {
      //   path: "my-access",
      //   name: "My Access",
      //   component: () => import("@/views/Access.vue"),
      //   meta: { title: "My Access" },
      // },
      // {
      //   path: "recent-activity",
      //   name: "Recent Activity",
      //   component: () => import("@/views/Activity.vue"),
      //   meta: { title: "Recent Activity" },
      // },
      // {
      //   path: "security-info",
      //   name: "Security Info",
      //   component: () => import("@/views/SecurityInfo.vue"),
      //   meta: { title: "Security Info" },
      // },
    ],
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

export default router
