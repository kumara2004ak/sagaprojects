import { defineStore } from "pinia"
import { ref, computed } from "vue"





export const useMainStore = defineStore("main", () => {
  // State
  const sidebarOpen = ref(false)
  const user = ref({
    name: "John Doe",
    email: "john@example.com",
    avatar: null,
  })

  const stats = ref({
    totalDomains: 3,
    activeUsers: 127,
    totalProjects: 24,
    totalGroups: 4,
  })

  const groups = ref([
    {
      id: 1,
      name: "Development Team",
      joined: "Joined: Jan 15, 2025",
      purpose: "Software Development",
      owner: "Sarah Johnson",
      members: "12 members",
      status: "member",
      icon: "code",
    },
    {
      id: 2,
      name: "Design Guild",
      joined: "Joined: Mar 3, 2025",
      purpose: "UX/UI Design",
      owner: "Michael Chen",
      members: "8 members",
      status: "member",
      icon: "palette",
    },
    {
      id: 3,
      name: "Customer Success",
      joined: "Owner",
      purpose: "Customer Support",
      owner: "You",
      members: "7 members",
      status: "owner",
      icon: "headphones",
    },
    {
      id: 4,
      name: "Marketing Team",
      joined: "Joined: Feb 20, 2025",
      purpose: "Digital Marketing",
      owner: "Emma Wilson",
      members: "6 members",
      status: "member",
      icon: "megaphone",
    },
  ])

  // Actions
  const toggleSidebar = () => {
    sidebarOpen.value = !sidebarOpen.value
  }

  const closeSidebar = () => {
    sidebarOpen.value = false
  }

  // Getters
  const getGroupsByStatus = computed(() => (status) => {
    return groups.value.filter((group) => group.status === status)
  })

  return {
    // State
    sidebarOpen,
    user,
    stats,
    groups,
    // Actions
    toggleSidebar,
    closeSidebar,
    // Getters
    getGroupsByStatus,
  }
})
