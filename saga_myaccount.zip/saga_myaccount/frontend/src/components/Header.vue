<template>
  <header class="bg-white border-b border-gray-200 px-6 py-3 sticky top-0 z-50">
    <div class="flex items-center justify-between">
      <div class="flex items-center space-x-4">
        <button 
          @click="$emit('toggleSidebar')"
          class="lg:hidden p-2 text-gray-400 hover:text-gray-600"
        >
          <Menu class="h-5 w-5" />
        </button>
        <h1 class="text-xl font-semibold text-gray-900">Dashboard</h1>
      </div>
      
      <div class="flex items-center space-x-4">
 
        <!-- <div class="hidden md:block relative">
          <Search class="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search..."
            class="pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-64"
          />
        </div> -->
        
        <!-- Notifications -->
        <div class="relative">
          <button class="p-2 text-gray-400 hover:text-gray-600 relative">
            <Bell class="h-5 w-5" />
            <span class="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full"></span>
          </button>
        </div>
        
        <!-- User Menu -->
        <div class="relative">
          <button 
            @click="showUserMenu = !showUserMenu"
            class="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-100"
          >
            <div class="h-8 w-8 rounded-full bg-gray-800 flex items-center justify-center">
              <User class="h-4 w-4 text-white" />
            </div>
            <ChevronDown class="h-4 w-4 text-gray-400" />
          </button>
          
          <!-- User Dropdown -->
          <div 
            v-if="showUserMenu"
            class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-200 z-50"
          >
            <div class="py-1">
              <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</a>
              <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</a>
              <hr class="my-1">
              <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Sign out</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
</template>

<script setup>
import { ref } from 'vue'
import { Bell, User, Search, Menu, ChevronDown } from 'lucide-vue-next'

defineEmits(['toggleSidebar'])

const showUserMenu = ref(false)
</script>
