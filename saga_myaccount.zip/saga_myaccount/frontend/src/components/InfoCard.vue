<template>
  <div class="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-md transition-shadow">
    <div class="flex items-center space-x-4">
      <div :class="[
        'h-12 w-12 rounded-full flex items-center justify-center',
        iconBgClass
      ]">
        <component :is="iconComponent" :class="['h-6 w-6', iconColorClass]" />
      </div>
      <div class="flex-1">
        <p class="text-sm font-medium text-gray-600">{{ title }}</p>
        <p class="text-3xl font-bold text-gray-900 mt-1">{{ formattedValue }}</p>
        <div v-if="change" class="flex items-center mt-2">
          <component 
            :is="change.trend === 'up' ? TrendingUp : TrendingDown" 
            :class="[
              'h-4 w-4 mr-1',
              change.trend === 'up' ? 'text-green-500' : 'text-red-500'
            ]"
          />
          <span :class="[
            'text-sm font-medium',
            change.trend === 'up' ? 'text-green-600' : 'text-red-600'
          ]">
            {{ change.value }}%
          </span>
          <span class="text-sm text-gray-500 ml-1">vs last month</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { Globe, Users, BarChart, TrendingUp, TrendingDown } from 'lucide-vue-next'

const props = defineProps({
  title: String,
  value: [String, Number],
  icon: { type: String, default: 'globe' },
  color: { type: String, default: 'blue' },
  change: Object
})

const iconComponent = computed(() => {
  const icons = { globe: Globe, users: Users, chart: BarChart }
  return icons[props.icon] || Globe
})

const iconBgClass = computed(() => {
  const colors = {
    blue: 'bg-blue-100',
    green: 'bg-green-100',
    purple: 'bg-purple-100',
    orange: 'bg-orange-100'
  }
  return colors[props.color] || 'bg-blue-100'
})

const iconColorClass = computed(() => {
  const colors = {
    blue: 'text-blue-600',
    green: 'text-green-600',
    purple: 'text-purple-600',
    orange: 'text-orange-600'
  }
  return colors[props.color] || 'text-blue-600'
})

const formattedValue = computed(() => {
  if (typeof props.value === 'number' && props.value > 999) {
    return (props.value / 1000).toFixed(1) + 'K'
  }
  return props.value
})
</script>
