<template>
  <aside class="w-64 bg-white border-r border-gray-200 min-h-screen">
    <div class="p-4">
      <!-- Logo -->
      <div class="flex items-center space-x-3 mb-6">
        <div class="h-8 w-8 bg-blue-600 rounded-lg flex items-center justify-center">
          <span class="text-white font-semibold text-sm">S</span>
        </div>
        <span class="font-semibold text-gray-900">SagalD</span>
      </div>

      <!-- Navigation -->
      <nav class="space-y-2">
        <div
          v-for="item in sidebarItems"
          :key="item.name"
          class="space-y-1"
        >
          <!-- Parent -->
          <button
            @click="toggleItem(item)"
            :class="[
              'w-full flex items-center justify-between px-3 py-2 text-sm rounded-md transition-colors',
              item.active ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'
            ]"
          >
            <div class="flex items-center space-x-3">
              <component :is="item.icon" class="h-4 w-4" />
              <span>{{ item.name }}</span>
            </div>
            <ChevronDown
              v-if="item.hasChildren"
              :class="['h-4 w-4 transition-transform', item.expanded ? 'rotate-180' : '']"
            />
          </button>

          <!-- Children -->
          <div
            v-if="item.expanded && item.children"
            class="ml-6 space-y-1"
          >
            <button
              v-for="child in item.children"
              :key="child.name"
              :class="[
                'w-full text-left px-3 py-2 text-sm rounded-md transition-colors',
                child.active ? 'bg-blue-50 text-blue-700' : 'text-gray-600 hover:bg-gray-50'
              ]"
              @click="setActiveChild(item, child)"
            >
              {{ child.name }}
            </button>
          </div>
        </div>
      </nav>
    </div>
  </aside>
</template>

<script setup>
import { ref } from "vue"
import { useRouter } from "vue-router"
import {
  ChevronDown,
  Home,
} from "lucide-vue-next"

const router = useRouter()

const sidebarItems = ref([
  {
    name: "My Account",
    icon: Home,
    hasChildren: true,
    expanded: true,
    active: true,
    children: [
      { name: "Profile", route: "/my-profile", active: true },
      { name: "My Groups", route: "/my-groups", active: false },
      // { name: "My Apps", route: "/my-apps", active: false },
      // { name: "My Access", route: "/my-access", active: false },
      { name: "Recent Activity", route: "/recent-activity", active: false },
      { name: "Security Info", route: "/security-info", active: false },
    ],
  },
])

const toggleItem = (item) => {
  if (item.hasChildren) {
    item.expanded = !item.expanded
  } else if (item.route) {
    router.push(item.route)
  }
}

const setActiveChild = (parent, child) => {
  sidebarItems.value.forEach((item) => {
    item.active = false
    if (item.children) {
      item.children.forEach((c) => (c.active = false))
    }
  })

  parent.active = true
  child.active = true

  if (child.route) {
    router.push(child.route)
  }
} 
</script>
