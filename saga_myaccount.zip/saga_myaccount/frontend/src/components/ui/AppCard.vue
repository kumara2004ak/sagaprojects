<template>
  <div class="bg-white overflow-hidden shadow rounded-lg">
    <div class="p-5">
      <div class="flex items-center justify-between">
        <div class="flex items-center">
          <div :class="[
            'h-10 w-10 rounded-lg flex items-center justify-center mr-4',
            iconBgClass
          ]">
            <FileText :class="['h-6 w-6', iconColorClass]" />
          </div>
          <div>
            <h3 class="text-lg font-medium text-gray-900">{{ title }}</h3>
            <p class="text-sm text-gray-500">{{ subtitle }}</p>
          </div>
        </div>
        <div class="flex flex-col items-end space-y-2">
          <span :class="[
            'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
            statusClass
          ]">
            <div :class="['w-2 h-2 rounded-full mr-1.5', statusDotClass]"></div>
            {{ status }}
          </span>
          <button 
            @click="$emit('launch', title)"
            :disabled="status === 'inactive'"
            :class="[
              'px-3 py-1.5 text-sm font-medium rounded-md transition-colors',
              status === 'inactive' 
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-primary-600 text-white hover:bg-primary-700'
            ]"
          >
            {{ status === 'inactive' ? 'Unavailable' : 'Launch' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { FileText } from 'lucide-vue-next'

const props = defineProps({
  title: String,
  subtitle: String,
  status: { type: String, default: 'active' },
  color: { type: String, default: 'orange' }
})

defineEmits(['launch'])

const iconBgClass = computed(() => {
  const colors = {
    blue: 'bg-blue-100',
    green: 'bg-green-100',
    purple: 'bg-purple-100',
    orange: 'bg-orange-100'
  }
  return colors[props.color] || 'bg-orange-100'
})

const iconColorClass = computed(() => {
  const colors = {
    blue: 'text-blue-600',
    green: 'text-green-600',
    purple: 'text-purple-600',
    orange: 'text-orange-600'
  }
  return colors[props.color] || 'text-orange-600'
})

const statusClass = computed(() => {
  const statuses = {
    active: 'bg-green-100 text-green-800',
    inactive: 'bg-red-100 text-red-800',
    pending: 'bg-yellow-100 text-yellow-800'
  }
  return statuses[props.status] || 'bg-green-100 text-green-800'
})

const statusDotClass = computed(() => {
  const dots = {
    active: 'bg-green-400',
    inactive: 'bg-red-400',
    pending: 'bg-yellow-400'
  }
  return dots[props.status] || 'bg-green-400'
})
</script>
