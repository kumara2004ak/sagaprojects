<template>
  <div class="bg-white overflow-hidden shadow rounded-lg">
    <div class="p-5">
      <div class="flex items-center">
        <div class="flex-shrink-0">
          <div :class="[
            'h-8 w-8 rounded-md flex items-center justify-center',
            iconBgClass
          ]">
            <component :is="iconComponent" :class="['h-5 w-5', iconColorClass]" />
          </div>
        </div>
        <div class="ml-5 w-0 flex-1">
          <dl>
            <dt class="text-sm font-medium text-gray-500 truncate">{{ title }}</dt>
            <dd class="text-lg font-medium text-gray-900">{{ formattedValue }}</dd>
          </dl>
        </div>
      </div>
    </div>
    <div v-if="change" class="bg-gray-50 px-5 py-3">
      <div class="text-sm">
        <component 
          :is="change.trend === 'up' ? TrendingUp : TrendingDown" 
          :class="[
            'inline h-4 w-4 mr-1',
            change.trend === 'up' ? 'text-green-500' : 'text-red-500'
          ]"
        />
        <span :class="[
          'font-medium',
          change.trend === 'up' ? 'text-green-600' : 'text-red-600'
        ]">
          {{ change.value }}%
        </span>
        <span class="text-gray-500"> from last month</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { Globe, Users, BarChart, TrendingUp, TrendingDown } from 'lucide-vue-next'

const props = defineProps({
  title: String,
  value: [String, Number],
  icon: { type: String, default: 'globe' },
  color: { type: String, default: 'blue' },
  change: Object
})

const iconComponent = computed(() => {
  const icons = { globe: Globe, users: Users, chart: BarChart }
  return icons[props.icon] || Globe
})

const iconBgClass = computed(() => {
  const colors = {
    blue: 'bg-blue-100',
    green: 'bg-green-100',
    purple: 'bg-purple-100',
    orange: 'bg-orange-100'
  }
  return colors[props.color] || 'bg-blue-100'
})

const iconColorClass = computed(() => {
  const colors = {
    blue: 'text-blue-600',
    green: 'text-green-600',
    purple: 'text-purple-600',
    orange: 'text-orange-600'
  }
  return colors[props.color] || 'text-blue-600'
})

const formattedValue = computed(() => {
  if (typeof props.value === 'number' && props.value > 999) {
    return (props.value / 1000).toFixed(1) + 'K'
  }
  return props.value
})
</script>
