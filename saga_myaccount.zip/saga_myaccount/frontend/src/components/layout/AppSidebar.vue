<template>
  <div :class="[
    'fixed inset-y-0 z-50 flex w-64 flex-col transition-transform duration-300 ease-in-out lg:translate-x-0',
    mainStore.sidebarOpen ? 'translate-x-0' : '-translate-x-full'
  ]">
    <div class="flex grow flex-col gap-y-5 overflow-y-auto bg-white px-6 pb-4 border-r border-gray-200">

      <div class="flex h-16 shrink-0 items-center">
        <div class="flex items-center space-x-3">
          <div class="h-8 w-8 bg-primary-600 rounded-lg flex items-center justify-center">
            <span class="text-white font-semibold text-sm">S</span>
          </div>
          <span class="font-semibold text-gray-900 text-lg">SagalD</span>
        </div>
      </div>
      
     
      <nav class="flex flex-1 flex-col">
        <ul role="list" class="flex flex-1 flex-col gap-y-7">
          <li>
            <ul role="list" class="-mx-2 space-y-1">
              <li v-for="item in navigation" :key="item.name">
               
                <router-link
                  v-if="!item.children"
                  :to="item.href"
                  :class="[
                    $route.name === item.name
                      ? 'bg-primary-50 text-primary-700'
                      : 'text-gray-700 hover:text-primary-700 hover:bg-gray-50',
                    'group flex gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold'
                  ]"
                >
                  <component
                    :is="item.icon"
                    :class="[
                      $route.name === item.name ? 'text-primary-700' : 'text-gray-400 group-hover:text-primary-700',
                      'h-6 w-6 shrink-0'
                    ]"
                  />
                  {{ item.name }}
                </router-link>

               
                <div v-else>
                  <button
                    @click="item.expanded = !item.expanded"
                    :class="[
                      item.current ? 'bg-primary-50 text-primary-700' : 'text-gray-700 hover:text-primary-700 hover:bg-gray-50',
                      'group flex w-full items-center gap-x-3 rounded-md p-2 text-left text-sm leading-6 font-semibold'
                    ]"
                  >
                    <component
                      :is="item.icon"
                      :class="[
                        item.current ? 'text-primary-700' : 'text-gray-400 group-hover:text-primary-700',
                        'h-6 w-6 shrink-0'
                      ]"
                    />
                    {{ item.name }}
                    <ChevronRight
                      :class="[
                        item.expanded ? 'rotate-90 text-gray-500' : 'text-gray-400',
                        'ml-auto h-5 w-5 shrink-0 transition-transform'
                      ]"
                    />
                  </button>
                  <ul v-if="item.expanded" class="mt-1 px-2">
                    <li v-for="subItem in item.children" :key="subItem.name">
                      <router-link
                        :to="subItem.href"
                        :class="[
                          $route.name === subItem.name
                            ? 'bg-primary-50 text-primary-700'
                            : 'text-gray-700 hover:text-primary-700 hover:bg-gray-50',
                          'block rounded-md py-2 pl-9 pr-2 text-sm leading-6'
                        ]"
                      >
                        {{ subItem.name }}
                      </router-link>
                    </li>
                  </ul>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ChevronRight } from 'lucide-vue-next'
import { 
  Home, 
  Users, 
  Building, 
  Briefcase, 
  Shield, 
  BarChart, 
  Settings,
  Link
} from 'lucide-vue-next'
import { useMainStore } from '@/stores/main'

const mainStore = useMainStore()

const navigation = ref([
  { name: 'Dashboard', href: '/', icon: Home },
  { name: 'Directory', href: '/directory', icon: Users },
  { name: 'Organization', href: '/organization', icon: Building },
  {
    name: 'My Account',
    icon: Home,
    expanded: false,
    children: [
      { name: 'Profile', href: '/profile' },
      { name: 'My Apps', href: '/myapps' },
      { name: 'My Groups', href: '/mygroups' },
      { name: 'My Access', href: '/myaccess' },
      { name: 'Recent Activity', href: '/recentactivity' },
      { name: 'Security Info', href: '/securityinfo' }
    ],
  },
  { name: 'Workspace', href: '/workspace', icon: Briefcase },
  { name: 'Security', href: '/security', icon: Shield },
  { name: 'Reports', href: '/reports', icon: BarChart },
  { name: 'Settings', href: '/settings', icon: Settings },
])
</script>
