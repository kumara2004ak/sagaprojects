<template>
  <div class="bg-white shadow rounded-lg">
    <div class="px-6 py-4 border-b border-gray-200">
      <div class="flex items-center justify-between">
        <h3 class="text-lg font-medium text-gray-900">All Groups</h3>
        <div class="relative">
          <Search class="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Search groups..."
            class="pl-10 pr-4 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
          />
        </div>
      </div>
    </div>
    
    <div class="overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
          <tr>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Group Name
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Purpose
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Owner
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Members
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
          <tr v-for="group in filteredGroups" :key="group.id" class="hover:bg-gray-50">
            <td class="px-6 py-4 whitespace-nowrap">
              <div class="flex items-center">
                <div :class="[
                  'h-10 w-10 rounded-md flex items-center justify-center mr-3',
                  getIconBg(group.icon)
                ]">
                  <component :is="getIcon(group.icon)" :class="['h-5 w-5', getIconColor(group.icon)]" />
                </div>
                <div>
                  <div class="text-sm font-medium text-gray-900">{{ group.name }}</div>
                  <div class="text-sm text-gray-500">{{ group.joined }}</div>
                </div>
              </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
              {{ group.purpose }}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-primary-600 hover:text-primary-800 cursor-pointer">
              {{ group.owner }}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
              {{ group.members }}
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
              <span :class="[
                'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
                group.status === 'owner' ? 'bg-primary-100 text-primary-800' : 'bg-gray-100 text-gray-800'
              ]">
                {{ group.status }}
              </span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm">
              <button class="text-primary-600 hover:text-primary-900 font-medium">
                View Details
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { Search, Code, Palette, Headphones, Megaphone } from 'lucide-vue-next'

const props = defineProps({
  groups: Array
})

const searchQuery = ref('')

const filteredGroups = computed(() => {
  if (!searchQuery.value) return props.groups
  return props.groups.filter(group => 
    group.name.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
    group.purpose.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})

const getIcon = (iconName) => {
  const icons = {
    code: Code,
    palette: Palette,
    headphones: Headphones,
    megaphone: Megaphone
  }
  return icons[iconName] || Code
}

const getIconBg = (iconName) => {
  const backgrounds = {
    code: 'bg-blue-100',
    palette: 'bg-green-100',
    headphones: 'bg-gray-100',
    megaphone: 'bg-purple-100'
  }
  return backgrounds[iconName] || 'bg-blue-100'
}

const getIconColor = (iconName) => {
  const colors = {
    code: 'text-blue-600',
    palette: 'text-green-600',
    headphones: 'text-gray-600',
    megaphone: 'text-purple-600'
  }
  return colors[iconName] || 'text-blue-600'
}
</script>
