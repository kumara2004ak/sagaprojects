<template>
  <div class="bg-white shadow rounded-lg">
    <div class="p-6 text-center">
      <Briefcase class="mx-auto h-12 w-12 text-gray-400" />
      <h3 class="mt-2 text-sm font-medium text-gray-900">No designations</h3>
      <p class="mt-1 text-sm text-gray-500">Get started by creating a new designation.</p>
    </div>
  </div>
</template>

<script setup>
import { Briefcase } from 'lucide-vue-next'
</script>
